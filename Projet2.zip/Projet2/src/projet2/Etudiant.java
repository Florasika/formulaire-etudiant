/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projet2;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author noudo
 */
public class Etudiant {
    private int id;
    private String nom,prenom,lieu_naissance,nationalite,filiere,statut;
    private Date date_naissance;
    
    public Etudiant()
    {
        
    }
    
    public Etudiant(int id, String nom,String prenom,Date date_naissance,String lieu_naissance,String nationalite,String filiere,String statut)
    {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.date_naissance = date_naissance;
        this.lieu_naissance = lieu_naissance;
        this.nationalite = nationalite;
        this.filiere = filiere;
        this.statut = statut;
        
    }
    
        public Etudiant(String nom,String prenom,Date date_naissance,String lieu_naissance,String nationalite,String filiere,String statut)
    {
        this.nom = nom;
        this.prenom = prenom;
        this.date_naissance = date_naissance;
        this.lieu_naissance = lieu_naissance;
        this.nationalite = nationalite;
        this.filiere = filiere;
        this.statut = statut;
        
    }


    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getLieu_naissance() {
        return lieu_naissance;
    }

    public String getNationalite() {
        return nationalite;
    }

    public String getFiliere() {
        return filiere;
    }

    public String getStatut() {
        return statut;
    }

    public Date getDate_naissance() {
        return date_naissance;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setLieu_naissance(String lieu_naissance) {
        this.lieu_naissance = lieu_naissance;
    }

    public void setNationalite(String nationalite) {
        this.nationalite = nationalite;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public void setDate_naissance(Date date_naissance) {
        this.date_naissance = date_naissance;
    }

    @Override
    public String toString() {
        return "Etudiant{" + "id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", lieu_naissance=" + lieu_naissance + ", nationalite=" + nationalite + ", filiere=" + filiere + ", statut=" + statut + ", date_naissance=" + date_naissance + '}';
    }

   
    
    
}

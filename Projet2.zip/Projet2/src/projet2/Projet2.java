/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projet2;

import Connexion.Connect;
import java.sql.SQLException;
import projet2.FormEtudiant;

/**
 *
 * @author noudo
 */
public class Projet2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        //Connect.se_connecter();
        new FormEtudiant().setVisible(true);   
    }  
}

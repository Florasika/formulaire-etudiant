/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connexion;

import java.sql.*; 
import com.mysql.jdbc.Driver;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author noudo
 */
public class Connect {
    public static Connection se_connecter()
    {
        try {
            //Chargement du driver
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Renseignement des,identifiants de connexion
        String url = "jdbc:mysql://localhost/testjava?characterEncoding=utf8";
        String username = "root";
        String password = "";
        
        
        try {
            Connection con = DriverManager.getConnection(url, username, password);
            //JOptionPane.showMessageDialog(null, "Connexion réuissie");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
  
          }
